<!doctype html>
<html class="no-js" lang="">

<head>
  <meta charset="utf-8">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>Popular HOSPITAL</title>
  <meta name="description" content="">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <link rel="manifest" href="site.webmanifest">
  <link rel="apple-touch-icon" href="icon.png">
  <link href="https://fonts.googleapis.com/css?family=Dosis:400,700|Lato:300,300i,400" rel="stylesheet">
  <link rel="stylesheet" href="css/fontawesome-all.css">
<link rel="stylesheet" href="css/bootstrap.css">
<link rel="stylesheet" href="css/style.css">

</head>

<body>

 <!--        1st nav ends   --> 
      
        <div class="container-fluid custom_top">
        <div class="row cover_img">
            <div class="col-xs-3 col-sm-3 col-md-3">
                <div class="pro_icon">
                    <img src="img/doctorologo.jpg" alt="">
                </div>


            </div>
           <div class="col-xs-3 col-sm-3 col-md-3">
                  <nav class="global-header__nav global-nav visually-hidden js-global-nav" role="navigation">
                        <ul class="global-nav_list">
                            <li class="global-nav__item"><a class="global-nav_link" href="Hospital.html" target="_top">Which hospital you are looking for?? </a></li>
             
                        </ul>
                    </nav>


            </div>
                 <div class="col-xs-3 col-sm-3 col-md-3">
              


            </div>


        </div>
           <nav class="navbar navbar-expand-lg navbar-light bg-light custom_menu">
          
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
            <div class="collapse navbar-collapse custom_navbar" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item custom_nav active">
                        <a class="nav-link " href="home.php">Home <span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item custom_nav">
                        <a class="nav-link " href="Hospital.html">Doctor Profile</a>
                    </li>
                    <li class="nav-item custom_nav">
                        <a class="nav-link " href="support.html">Online Support</a>
                    </li>
                    <li class="nav-item custom_nav">
                       <a class="nav-link " href="Surgeon.html">Surgeon</a>
                    </li>
                   
                    <li class="nav-item custom_nav">
                        <a class="nav-link " href="about.html">About</a>
                    </li>
                </ul>
            </div>
        </nav>

</div>


    
  <!--        2nd nav ends  -->

  
<!--  hospital start-->
<section id="hospital"   style="background-image: url(img/background.png);
    background-position: center;
    background-size: cover; 
    background-repeat: no-repeat;">
    <div class="container" style="margin-bottom: 40px;">
    <div class="container" style="margin-bottom: 40px;">
        <div class="row">
            <div class="col-md-10 offset-md-1">
               <div class="hospial_content text-center" style="margin-top: 100px;">
                <h1 style="font-size: 30pt;
font-weight: bold;">Popular Hospital</h1>
         
                </div>
            </div>
            
        </div>
        
        <div class="row" style="margin: 40px 0px;">
            
 
          <!--                       -->  
            
            
                 <div class="col-md-6 col-lg-3">
                 <div class="card">
                     <div class="card-header card_custom_header2 text-center">
                     <span>Medicine Specialist</span><span class="card_img"> <img src="img/card_logo1.png" class="imh-fluid" alt="card_logo"> </span>
  </div>
                    <img class="card-img-top" src="img/Male_Doctor.png">
                    <div class="card-block">
                        <figure class="profile">
                            <img src="img/price2.png" class="profile-avatar" alt="">
                        </figure>
                        <h4 class="card-title2 text-center mt-3 custom_last" style="color: #56d47e !important;">PROF. DR. KHAN ABUL KALAM AZAD</h4>
                       
                        <div class="card-text text-center">
                          MBBS(DMC), FCPS(MED.), MD(INTERNAM MED.), FACP(USA)
SPECIALTY: MEDICINE
Visiting Hour : 5 PM - 9 PM, Closed : THURSDAY &nbsp; FRIDAY
                          </div>
                           </div>
                    <div class="card-footer text-center">
                       <span class="float-left leftone"></span>
                       <span><a href="booking.php">Book Now</a></span>
                       <span class="float-right rightone"></span>
                    </div>
                </div>
            </div>
                
<!--                          -->
            
               <!--                       -->  
            
            
                 <div class="col-md-6 col-lg-3">
                 <div class="card">
                     <div class="card-header card_custom_header2 text-center">
                     <span>Medicine Specialist</span><span class="card_img"> <img src="img/card_logo1.png" class="imh-fluid" alt="card_logo"> </span>
  </div>
                    <img class="card-img-top" src="img/Male_Doctor.png">
                    <div class="card-block">
                        <figure class="profile">
                            <img src="img/price2.png" class="profile-avatar" alt="">
                        </figure>
                        <h4 class="card-title2 text-center mt-3 custom_last" style="color: #56d47e !important;">PROF. DR. QUAZI TARIKUL ISLAM</h4>
                       
                        <div class="card-text text-center">
                          MBBS, FCPS(MEDICINE), FACP(USA), FRCP(GLASG, UK), FRCP(EDIN)
SPECIALTY : MEDICINE
Visiting Hour : 5 PM - 9 PM, Closed : FRIDAY


                        </div>
                    </div>
                    <div class="card-footer text-center">
                       <span class="float-left leftone"></span>
                       <span><a href="booking.php">Book Now</a></span>
                       <span class="float-right rightone"></span>
                    </div>
                </div>
            </div>
                
<!--                          -->
            
            <!--                       -->  
            
            
                 <div class="col-md-6 col-lg-3">
                 <div class="card">
                     <div class="card-header card_custom_header2 text-center">
                     <span>Medicine Specialist</span><span class="card_img"> <img src="img/card_logo1.png" class="imh-fluid" alt="card_logo"> </span>
  </div>
                    <img class="card-img-top" src="img/Male_Doctor.png">
                    <div class="card-block">
                        <figure class="profile">
                            <img src="img/price2.png" class="profile-avatar" alt="">
                        </figure>
                        <h4 class="card-title2 text-center mt-3 custom_last" style="color: #56d47e !important;">PROF. DR. H A M NAZMUL AHSAN</h4>
                       
                        <div class="card-text text-center">
                          MBBS, FCPS, FRCP(GLASSGOW), FRCP(EDIN), FACP(USA)
SPECIALTY : MEDICINE
Visiting Hour: 5 PM - 8 PM, Closed: FRIDAY


                        </div>
                    </div>
                    <div class="card-footer text-center">
                       <span class="float-left leftone"></span>
                       <span><a href="booking.php">Book Now</a></span>
                       <span class="float-right rightone"></span>
                    </div>
                </div>
            </div>
                
<!--                          -->
            
            <!--                       -->  
            
            
                 <div class="col-md-6 col-lg-3">
                 <div class="card">
                     <div class="card-header card_custom_header2 text-center">
                     <span>Cardiologist</span><span class="card_img"> <img src="img/card_logo1.png" class="imh-fluid" alt="card_logo"> </span>
  </div>
                    <img class="card-img-top" src="img/Male_Doctor.png">
                    <div class="card-block">
                        <figure class="profile">
                            <img src="img/price2.png" class="profile-avatar" alt="">
                        </figure>
                        <h4 class="card-title2 text-center mt-3 custom_last" style="color: #56d47e !important;">PROF. DR. MD. ABU SIDDIQUE</h4>
                       
                        <div class="card-text text-center">
                         MBBS(DMC), PH.D(CARDIOLOGY), FPGCS(MEDICINE)
SPECIALTY : CARDIOLOGIST
Visiting Hour: 5 PM-9 PM, Closed: THURSDAY, FRIDAY & GOVT. HOLIDAY

                        </div>
                    </div>
                    <div class="card-footer text-center">
                       <span class="float-left leftone"></span>
                        <span><a href="booking.php">Book Now</a></span>
                       <span class="float-right rightone"></span>
                    </div>
                </div>
            </div>
                
<!--                          -->
            
            
               <!--                       -->  
            
            
                 <div class="col-md-6 col-lg-3">
                 <div class="card">
                     <div class="card-header card_custom_header2 text-center">
                     <span>Cardiologist</span><span class="card_img"> <img src="img/card_logo1.png" class="imh-fluid" alt="card_logo"> </span>
  </div>
                    <img class="card-img-top" src="img/Male_Doctor.png">
                    <div class="card-block">
                        <figure class="profile">
                            <img src="img/price2.png" class="profile-avatar" alt="">
                        </figure>
                        <h4 class="card-title2 text-center mt-3 custom_last" style="color: #56d47e !important;">PROF. DR. M. ABDULLAH-AL-SAFI MAJUMDER</h4>
                       
                        <div class="card-text text-center">
                        MBBS, D.CARD, MD(CARD), FACC, FSGC, FRCP
Director & Professor of Cardiology,National Institute of Cardiovascular Diseases,Dhaka
SPECIALTY: CARDIOLOGIST
Visiting Hour: 11AM-1PM & 5PM-7PM, Closed: FRIDAY

                        </div>
                    </div>
                    <div class="card-footer text-center">
                       <span class="float-left leftone"></span>
                      <span><a href="booking.php">Book Now</a></span>
                       <span class="float-right rightone"></span>
                    </div>
                </div>
            </div>
                
<!--                          -->
            
              <!--                       -->  
            
            
                 <div class="col-md-6 col-lg-3">
                 <div class="card">
                     <div class="card-header card_custom_header2 text-center">
                     <span>Cardiologist</span><span class="card_img"> <img src="img/card_logo1.png" class="imh-fluid" alt="card_logo"> </span>
  </div>
                    <img class="card-img-top" src="img/Male_Doctor.png">
                    <div class="card-block">
                        <figure class="profile">
                            <img src="img/price2.png" class="profile-avatar" alt="">
                        </figure>
                        <h4 class="card-title2 text-center mt-3 custom_last" style="color: #56d47e !important;">PROF. DR. KHANDAKER QAMRUL ISLAM</h4>
                       
                        <div class="card-text text-center">
                         MBBS, D.CARD(DU), MD(CARDIOLOGY), FACC(USA)
Professor of Cardiologist,,National Institue of Cardiovascular Diseases,Dhaka
SPECIALTY : CARDIOLOGIST
Visiting Hour: 7 PM-10 PM, Closed: TUESDAY,THURSDAY & FRIDAY
 
                        </div>
                    </div>
                    <div class="card-footer text-center">
                       <span class="float-left leftone"></span>
                        <span><a href="booking.php">Book Now</a></span>
                       <span class="float-right rightone"></span>
                    </div>
                </div>
            </div>
                
<!--                          -->
            
            <!--                       -->  
            
            
                 <div class="col-md-6 col-lg-3">
                 <div class="card">
                     <div class="card-header card_custom_header2 text-center">
                     <span>Gastroenterology</span><span class="card_img"> <img src="img/card_logo1.png" class="imh-fluid" alt="card_logo"> </span>
  </div>
                    <img class="card-img-top" src="img/Male_Doctor.png">
                    <div class="card-block">
                        <figure class="profile">
                            <img src="img/price2.png" class="profile-avatar" alt="">
                        </figure>
                        <h4 class="card-title2 text-center mt-3 custom_last" style="color: #56d47e !important;">PROF. DR. ANISUR RAHMAN</h4>
                       
                        <div class="card-text text-center">
                       MBBS, FCPS, TRAINED IN THERAPEUTIC ENDOSCOPY (JAPAN)
Professor & Senior Consultant(retd),Department of Gastrointestinal Liver and Pancreatic Disorder, BIRDEM(Diabetes) Hospital & Ibrahim Medical College
SPECIALTY: GASTROENTEROLOGY
Visiting Hour : 11 AM-1 PM & 6 PM-10 PM, Closed : FRIDAY
 
                        </div>
                    </div>
                    <div class="card-footer text-center">
                       <span class="float-left leftone"></span>
                        <span><a href="booking.php">Book Now</a></span>
                       <span class="float-right rightone"></span>
                    </div>
                </div>
            </div>
                
<!--                          -->
            
             <!--                       -->  
            
            
                 <div class="col-md-6 col-lg-3">
                 <div class="card">
                     <div class="card-header card_custom_header2 text-center">
                     <span>Gastroenterology</span><span class="card_img"> <img src="img/card_logo1.png" class="imh-fluid" alt="card_logo"> </span>
  </div>
                    <img class="card-img-top" src="img/Male_Doctor.png">
                    <div class="card-block">
                        <figure class="profile">
                            <img src="img/price2.png" class="profile-avatar" alt="">
                        </figure>
                        <h4 class="card-title2 text-center mt-3 custom_last" style="color: #56d47e !important;">PROF. DR. M T RAHMAN</h4>
                       
                        <div class="card-text text-center">
                      MBBS, FCPS, TRAINED IN FRANCE & JAPAN
SPECIALTY: GASTROENTEROLOGY
Visiting Hour: 11 AM-12:30 PM & 5 PM-9 PM, Closed : FRIDAY
 
                        </div>
                    </div>
                    <div class="card-footer text-center">
                       <span class="float-left leftone"></span>
                       <span><a href="booking.php">Book Now</a></span>
                       <span class="float-right rightone"></span>
                    </div>
                </div>
            </div>
                
<!--                          -->
            
                         <!--                       -->  
            
            
                 <div class="col-md-6 col-lg-3">
                 <div class="card">
                     <div class="card-header card_custom_header2 text-center">
                     <span>Neurology</span><span class="card_img"> <img src="img/card_logo1.png" class="imh-fluid" alt="card_logo"> </span>
  </div>
                    <img class="card-img-top" src="img/Female_Doctor.png">
                    <div class="card-block">
                        <figure class="profile">
                            <img src="img/price2.png" class="profile-avatar" alt="">
                        </figure>
                        <h4 class="card-title2 text-center mt-3 custom_last" style="color: #56d47e !important;">DR. RUMANA HABIB</h4>
                       
                        <div class="card-text text-center">
                       MBBS, FCPS(MEDICINE)
SPECIALTY : NEUROLOGY
Visiting Hour : 5 PM-7 PM, Closed : FRIDAY
 
                        </div>
                    </div>
                    <div class="card-footer text-center">
                       <span class="float-left leftone"></span>
                       <span><a href="booking.php">Book Now</a></span>
                       <span class="float-right rightone"></span>
                    </div>
                </div>
            </div>
                
<!--                          -->
            
                <!--                       -->  
            
            
                 <div class="col-md-6 col-lg-3">
                 <div class="card">
                     <div class="card-header card_custom_header2 text-center">
                     <span>Neurology</span><span class="card_img"> <img src="img/card_logo1.png" class="imh-fluid" alt="card_logo"> </span>
  </div>
                    <img class="card-img-top" src="img/Male_Doctor.png">
                    <div class="card-block">
                        <figure class="profile">
                            <img src="img/price2.png" class="profile-avatar" alt="">
                        </figure>
                        <h4 class="card-title2 text-center mt-3 custom_last" style="color: #56d47e !important;">PROF. DR. SYED WAHIDUR RAHMAN</h4>
                       
                        <div class="card-text text-center">
                      MBBS(DHAKA), FCPS(MEDICINE), TRAINED IN NEUROLOGY (AUSTRALIA)
Professor & Head(Trd.), Neuromedicine Department, Shaheed Suhrawardy Medical College & Hospital, Dhaka
SPECIALTY : NEUROLOGY
Visiting Hour : 6 PM-9 PM, Closed : THURSDAY & FRIDAY
 
                        </div>
                    </div>
                    <div class="card-footer text-center">
                       <span class="float-left leftone"></span>
                       <span><a href="booking.php">Book Now</a></span>
                       <span class="float-right rightone"></span>
                    </div>
                </div>
            </div>
                
<!--                          -->
            
            
             <!--                       -->  
            
            
                 <div class="col-md-6 col-lg-3">
                 <div class="card">
                     <div class="card-header card_custom_header2 text-center">
                     <span>Neurology</span><span class="card_img"> <img src="img/card_logo1.png" class="imh-fluid" alt="card_logo"> </span>
  </div>
                    <img class="card-img-top" src="img/Female_Doctor.png">
                    <div class="card-block">
                        <figure class="profile">
                            <img src="img/price2.png" class="profile-avatar" alt="">
                        </figure>
                        <h4 class="card-title2 text-center mt-3 custom_last" style="color: #56d47e !important;">DR. SAUMITRA SARKER</h4>
                       
                        <div class="card-text text-center">
                     MBBS, MS (NEUROSURGERY), FELLOW IN NEUROENDOSCOPY (INDIA), ADVANCED NEUROSURGUCAL TRAINING (JAPAN)
SPECIALTY : NEURO SURGEON
Visiting Hour : 6 PM-8 PM, Closed : THURSDAY,FRIDAY & SATURDAY
 
                        </div>
                    </div>
                    <div class="card-footer text-center">
                       <span class="float-left leftone"></span>
                       <span><a href="booking.php">Book Now</a></span>
                       <span class="float-right rightone"></span>
                    </div>
                </div>
            </div>
                
<!--                          -->
            
            
             <!--                       -->  
            
            
                 <div class="col-md-6 col-lg-3">
                 <div class="card">
                     <div class="card-header card_custom_header2 text-center">
                     <span>Diabetology</span><span class="card_img"> <img src="img/card_logo1.png" class="imh-fluid" alt="card_logo"> </span>
  </div>
                    <img class="card-img-top" src="img/Male_Doctor.png">
                    <div class="card-block">
                        <figure class="profile">
                            <img src="img/price2.png" class="profile-avatar" alt="">
                        </figure>
                        <h4 class="card-title2 text-center mt-3 custom_last" style="color: #56d47e !important;">PROF. DR. MD. FARID UDDIN</h4>
                       
                        <div class="card-text text-center">
                     MBBS, DEM, MD
SPECIALTY: DIABETOLOGIST AND ENDOCRINOLOGY
Visiting Hour: 5:30PM-8:30PM, Closed : FRIDAY
 
                        </div>
                    </div>
                    <div class="card-footer text-center">
                       <span class="float-left leftone"></span>
                      <span><a href="booking.php">Book Now</a></span>
                       <span class="float-right rightone"></span>
                    </div>
                </div>
            </div>
                
<!--                          -->
            
            
              <!--                       -->  
            
            
                 <div class="col-md-6 col-lg-3">
                 <div class="card">
                     <div class="card-header card_custom_header2 text-center">
                     <span>Orthopedic</span><span class="card_img"> <img src="img/card_logo1.png" class="imh-fluid" alt="card_logo"> </span>
  </div>
                    <img class="card-img-top" src="img/Male_Doctor.png">
                    <div class="card-block">
                        <figure class="profile">
                            <img src="img/price2.png" class="profile-avatar" alt="">
                        </figure>
                        <h4 class="card-title2 text-center mt-3 custom_last" style="color: #56d47e !important;">PROF. DR. MUHAMMAD SHAHIDUZZAMAN</h4>
                       
                        <div class="card-text text-center">
                    MBBS, MS(ORTHO), RCO(USA)
                    Professor and Head,Departmnet of Orthopaedic Surgery(Rtd),Dhaka Medical College & Hospital 
SPECIALTY : ORTHOPAEDICS SPECIALIST
Visiting Hour: 11AM-1PM, Closed: FRIDAY

                        </div>
                    </div>
                    <div class="card-footer text-center">
                       <span class="float-left leftone"></span>
                       <span><a href="booking.php">Book Now</a></span>
                       <span class="float-right rightone"></span>
                    </div>
                </div>
            </div>
                
<!--                          -->
            
            
             <!--                       -->  
            
            
                 <div class="col-md-6 col-lg-3">
                 <div class="card">
                     <div class="card-header card_custom_header2 text-center">
                     <span>Orthopedic</span><span class="card_img"> <img src="img/card_logo1.png" class="imh-fluid" alt="card_logo"> </span>
  </div>
                    <img class="card-img-top" src="img/Male_Doctor.png">
                    <div class="card-block">
                        <figure class="profile">
                            <img src="img/price2.png" class="profile-avatar" alt="">
                        </figure>
                        <h4 class="card-title2 text-center mt-3 custom_last" style="color: #56d47e !important;">PROF. DR. MOINUDDIN AHMED CHOWDHURY</h4>
                       
                        <div class="card-text text-center">
                   MBBS, MS(ORTHO), RCO(USA)
SPECIALTY: ORTHOPAEDICS SPECIALIST
Visiting Hour : 6 PM-9 PM, Closed: THURSDAY & FRIDAY

                        </div>
                    </div>
                    <div class="card-footer text-center">
                       <span class="float-left leftone"></span>
                        <span><a href="booking.php">Book Now</a></span>
                       <span class="float-right rightone"></span>
                    </div>
                </div>
            </div>
                
<!--                          -->
            
            
             <!--                       -->  
            
            
                 <div class="col-md-6 col-lg-3">
                 <div class="card">
                     <div class="card-header card_custom_header2 text-center">
                     <span>Orthopedic</span><span class="card_img"> <img src="img/card_logo1.png" class="imh-fluid" alt="card_logo"> </span>
  </div>
                    <img class="card-img-top" src="img/Male_Doctor.png">
                    <div class="card-block">
                        <figure class="profile">
                            <img src="img/price2.png" class="profile-avatar" alt="">
                        </figure>
                        <h4 class="card-title2 text-center mt-3 custom_last" style="color: #56d47e !important;">DR. MD. ANOWARUL ISLAM</h4>
                       
                        <div class="card-text text-center">
                  MBBS(DHAKA), MS(ORTHO), FICS(AMERICA)
SPECIALTY : ORTHOPAEDICS SPECIALIST
Visiting Hour : 5:30 PM - 9:00 PM
Closed : FRIDAY

                        </div>
                    </div>
                    <div class="card-footer text-center">
                       <span class="float-left leftone"></span>
                        <span><a href="booking.php">Book Now</a></span>
                       <span class="float-right rightone"></span>
                    </div>
                </div>
            </div>
                
<!--                          -->
            
            <!--                       -->  
            
            
                 <div class="col-md-6 col-lg-3">
                 <div class="card">
                     <div class="card-header card_custom_header2 text-center">
                     <span>GYNAECOLOGY</span><span class="card_img"> <img src="img/card_logo1.png" class="imh-fluid" alt="card_logo"> </span>
  </div>
                    <img class="card-img-top" src="img/Female_Doctor.png">
                    <div class="card-block">
                        <figure class="profile">
                            <img src="img/price2.png" class="profile-avatar" alt="">
                        </figure>
                        <h4 class="card-title2 text-center mt-3 custom_last" style="color: #56d47e !important;">PROF. DR. SAYEBA AKHTER</h4>
                       
                        <div class="card-text text-center">
                 MBBS, FCPS(BD), FCPS(PAK), FICMCH(IN), DRH(UK)
Ex. Professor of Obstretrics & Gynaecology,Bangabandhu Sheikh Mujib Medical University,Dhaka
SPECIALTY: OBSTETRICS AND GYNAECOLOGY
Visiting Hour : 6:30PM-7:30PM, Closed: THURSDAY & FRIDAY

                        </div>
                    </div>
                    <div class="card-footer text-center">
                       <span class="float-left leftone"></span>
                    <span><a href="booking.php">Book Now</a></span>
                       <span class="float-right rightone"></span>
                    </div>
                </div>
            </div>
                
<!--                          -->
            
            
             <!--                       -->  
            
            
                 <div class="col-md-6 col-lg-3">
                 <div class="card">
                     <div class="card-header card_custom_header2 text-center">
                     <span>GYNAECOLOGY</span><span class="card_img"> <img src="img/card_logo1.png" class="imh-fluid" alt="card_logo"> </span>
  </div>
                    <img class="card-img-top" src="img/Female_Doctor.png">
                    <div class="card-block">
                        <figure class="profile">
                            <img src="img/price2.png" class="profile-avatar" alt="">
                        </figure>
                        <h4 class="card-title2 text-center mt-3 custom_last" style="color: #56d47e !important;">PROF. DR. MRS. FARHAT HOSSAIN</h4>
                       
                        <div class="card-text text-center">
                 MBBS(DHAKA), FCPS(GYNAE)
SPECIALTY: OBSTETRICS AND GYNAECOLOGY
Visiting Hour: 6:30PM-8:30PM, Closed: FRIDAY, SATURDAY & GOVT. HOLIDAYS

                        </div>
                    </div>
                    <div class="card-footer text-center">
                       <span class="float-left leftone"></span>
                       <span><a href="booking.php">Book Now</a></span>
                       <span class="float-right rightone"></span>
                    </div>
                </div>
            </div>
                
<!--                          -->
            
            
            <!--                       -->  
            
            
                 <div class="col-md-6 col-lg-3">
                 <div class="card">
                     <div class="card-header card_custom_header2 text-center">
                     <span>GYNAECOLOGY</span><span class="card_img"> <img src="img/card_logo1.png" class="imh-fluid" alt="card_logo"> </span>
  </div>
                    <img class="card-img-top" src="img/Female_Doctor.png">
                    <div class="card-block">
                        <figure class="profile">
                            <img src="img/price2.png" class="profile-avatar" alt="">
                        </figure>
                        <h4 class="card-title2 text-center mt-3 custom_last" style="color: #56d47e !important;">DR. S. F. NARGIS</h4>
                       
                        <div class="card-text text-center">
                  MBBS, FCPS, MS
SPECIALTY : OBSTETRICS AND GYNAECOLOGY
Visiting Hour : 5 PM-7 PM
Closed : THURSDAY, FRIDAY & GOVT. HOLIDAYS

                        </div>
                    </div>
                    <div class="card-footer text-center">
                       <span class="float-left leftone"></span>
                       <span><a href="booking.php">Book Now</a></span>
                       <span class="float-right rightone"></span>
                    </div>
                </div>
            </div>
                
<!--                          -->
            
            
             <!--                       -->  
            
            
                 <div class="col-md-6 col-lg-3">
                 <div class="card">
                     <div class="card-header card_custom_header2 text-center">
                     <span>ENT (Ear, Nose & Throat)</span><span class="card_img"> <img src="img/card_logo1.png" class="imh-fluid" alt="card_logo"> </span>
  </div>
                    <img class="card-img-top" src="img/Male_Doctor.png">
                    <div class="card-block">
                        <figure class="profile">
                            <img src="img/price2.png" class="profile-avatar" alt="">
                        </figure>
                        <h4 class="card-title2 text-center mt-3 custom_last" style="color: #56d47e !important;">PROF. DR. MAJ (RTD) MD. ASHRAFUL ISLAM</h4>
                       
                        <div class="card-text text-center">
                  MBBS, FCPS, FICS(USA)
SPECIALTY: ENT SPECIALIST
Visiting Hour: 6 PM-9 PM, Closed : FRIDAY

                        </div>
                    </div>
                    <div class="card-footer text-center">
                       <span class="float-left leftone"></span>
                       <span><a href="booking.php">Book Now</a></span>
                       <span class="float-right rightone"></span>
                    </div>
                </div>
            </div>
                
<!--                          -->
            
            
             <!--                       -->  
            
            
                 <div class="col-md-6 col-lg-3">
                 <div class="card">
                     <div class="card-header card_custom_header2 text-center">
                     <span>ENT (Ear, Nose & Throat)</span><span class="card_img"> <img src="img/card_logo1.png" class="imh-fluid" alt="card_logo"> </span>
  </div>
                    <img class="card-img-top" src="img/Male_Doctor.png">
                    <div class="card-block">
                        <figure class="profile">
                            <img src="img/price2.png" class="profile-avatar" alt="">
                        </figure>
                        <h4 class="card-title2 text-center mt-3 custom_last" style="color: #56d47e !important;">PROF. DR. MOHAMMAD ABDULLAH</h4>
                       
                        <div class="card-text text-center">
                  FCPS, FICS
SPECIALTY: ENT SPECIALIST
Visiting Hour: 6PM- 9PM, Closed: FRIDAY
 

                        </div>
                    </div>
                    <div class="card-footer text-center">
                       <span class="float-left leftone"></span>
                        <span><a href="booking.php">Book Now</a></span>
                       <span class="float-right rightone"></span>
                    </div>
                </div>
            </div>
                
<!--                          -->
            
             <!--                       -->  
            
            
                 <div class="col-md-6 col-lg-3">
                 <div class="card">
                     <div class="card-header card_custom_header2 text-center">
                     <span>SKIN AND SEX DISEASE SPECIALIST</span><span class="card_img"> <img src="img/card_logo1.png" class="imh-fluid" alt="card_logo"> </span>
  </div>
                    <img class="card-img-top" src="img/Male_Doctor.png">
                    <div class="card-block">
                        <figure class="profile">
                            <img src="img/price2.png" class="profile-avatar" alt="">
                        </figure>
                        <h4 class="card-title2 text-center mt-3 custom_last" style="color: #56d47e !important;">PROF. DR. M MUJIBUL HOQUE</h4>
                       
                        <div class="card-text text-center">
                 FCPS, FRCP, DDV(DU), DDV(AUSTRIA)
Ex. Head of Department,Skin & VD,Dhaka Medical college & Hospital,Dhaka
SPECIALTY: SKIN AND SEX DISEASE SPECIALIST
Visiting Hour: 5PM-9PM, Closed: FRIDAY


                        </div>
                    </div>
                    <div class="card-footer text-center">
                       <span class="float-left leftone"></span>
                      <span><a href="booking.php">Book Now</a></span>
                       <span class="float-right rightone"></span>
                    </div>
                </div>
            </div>
                
<!--                          -->
            
            
              <!--                       -->  
            
            
                 <div class="col-md-6 col-lg-3">
                 <div class="card">
                     <div class="card-header card_custom_header2 text-center">
                     <span>SKIN AND SEX DISEASE SPECIALIST</span><span class="card_img"> <img src="img/card_logo1.png" class="imh-fluid" alt="card_logo"> </span>
  </div>
                    <img class="card-img-top" src="img/Male_Doctor.png">
                    <div class="card-block">
                        <figure class="profile">
                            <img src="img/price2.png" class="profile-avatar" alt="">
                        </figure>
                        <h4 class="card-title2 text-center mt-3 custom_last" style="color: #56d47e !important;">PROF. DR. KAZI A. KARIM</h4>
                       
                        <div class="card-text text-center">
                  MBBS(DHK), DDV(VIEN), MSSVD(LOND)
SPECIALTY : SKIN AND SEX DISEASE SPECIALIST
Visiting Hour : 5 PM- 9 PM
Closed : FRIDAY & GOVT. HOLIDAYS
 
                        </div>
                    </div>
                    <div class="card-footer text-center">
                       <span class="float-left leftone"></span>
                      <span><a href="booking.php">Book Now</a></span>
                       <span class="float-right rightone"></span>
                    </div>
                </div>
            </div>
                
<!--                          -->

          
            </div>
         
            
        </div>
    </div>
  
    
</section>

<!--  hospital end-->

  
   <script src="js/jquery-3.3.1.min.js"></script>
<script src="js/bootstrap.js"></script>
<script src="js/main.js"></script>
  
</body>

</html>
